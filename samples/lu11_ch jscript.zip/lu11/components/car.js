class Car{
    constructor(
        make,
        model,
        color,
        year,
    ){
        this.make = make;
        this.model = model;
        this.color = color;
        this.year = year;
    }
    
}


export default Car;