import Car from "./car.js";

const car1 = new Car(
    "Toyota",
    "Corolla",
    "Silver",
    2015,
);
const car2 = new Car(
    "Toyota",
    "Celica",
    "Yellow",
    2003,
);
const car3 = new Car(
    "Chevrolet",
    "Escalade",
    "Black",
    2022,
);

const carObjectArray = [car1, car2, car3];
export default carObjectArray;