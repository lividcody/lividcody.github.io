import carObjectArray from "./components/data.js";
import Car from "./components/car.js";



const createCar = (make, model, color, year) => {
    const newCar = new Car (make, model, color, year)
    carObjectArray.push(newCar)
};

const myForm = document.getElementById("myForm")
myForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const make = document.getElementById("maketext").value;
    const model = document.getElementById("modeltext").value;
    const color = document.getElementById("colortext").value;
    const year = document.getElementById("yeartext").value;
    createCar(make,model,color,year);
    updateScreen();
});

const updateScreen=() =>{
    const content = carObjectArray.map((car) => {
        let carArticle = document.createElement("article");
        carArticle.classList.add("car");    
        carArticle.setAttribute("id", car.id);
        console.log(carObjectArray)
    //template
    
        carArticle.innerHTML=
        `
        <li class="car_make">${car.make}</li>
        <li class="car_model">${car.model}</li>
        <li class="car_color">${car.color}</li>
        <li class="car_year">${car.year}</li>
        <br>
        `;
        return carArticle;
    });    
    const main = document.querySelector(".secondarycontent");

    content.forEach((car)=>{
        main.append(car);
    });
};
updateScreen();

   
