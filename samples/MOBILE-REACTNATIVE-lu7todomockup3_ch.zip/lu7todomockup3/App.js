import React, {useState} from 'react';
import { Text, View, StyleSheet, TextInput, ScrollView } from 'react-native';
import TasksItem from './components/tasksItem'
import AddItem from './components/addItem'
import Header from './components/header'
import Footer from './components/footer'

export default function App(){
  const [tasks, setTasks] = useState([
    {name: 'Wash Dishes', key: '1'},
    {name: 'Take out Trash', key: '2'},
    {name: 'Take Trash to Curb', key: '3'},
    {name: 'Mow Lawn', key: '4'},
    {name: 'Fix Car', key: '5'},
    {name: 'Take in Recycling', key: '6'},
    {name: 'Clean Bathroom', key: '7'},
    {name: 'Mop Floors', key: '8'},
    {name: 'Wash Laundry', key: '9'},
    {name: 'Fold Laundry', key: '10'},
  ])

const pressHandler = (key) => {
    console.log(tasks)
    setTasks ((prevTasks) => {
      return(
        prevTasks.filter(tasks => tasks.key != key)
      )
    }) 
  }
  
  const submitHandler = (text) => {
    setTasks((prevTasks) => {
      return[
        {name: text, key: Math.random().toString()},
        ...prevTasks
      ]
    })
  }

return (  
  <View style={styles.container}>
    <Header></Header>
    <View>
      <AddItem submitHandler={submitHandler}/>
    </View>

<ScrollView>
          {tasks.map((item) => {
            return(
              <View>
                <TasksItem item={item} pressHandler={pressHandler}/>
              </View>
            )
          })}
        </ScrollView>
    <Footer></Footer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#808080',
    paddingTop: 40,
    paddingHorizontal: 10,
  },
});