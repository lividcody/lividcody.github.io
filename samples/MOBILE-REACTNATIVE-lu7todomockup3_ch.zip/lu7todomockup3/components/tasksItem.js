import React from 'react';
import {Text, StyleSheet, TouchableOpacity, Image, View} from 'react-native';
import checkPic from './pics/checkmark.jpg'

export default function TasksItem({item, pressHandler}){
  return(
    <TouchableOpacity onPress={() => pressHandler(item.key)} styles={styles.container}>
      <View style={styles.itemContainer}>
        <Text style={styles.item}>{item.name}</Text>
        <Image source={checkPic} style={styles.button}/>
      </View>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  item: {
    flex: 1,
    marginTop: 5,
    padding: 10,
    backgroundColor: 'black',
    color: 'white',
    fontSize: 24,
    textAlign: "center",
    width: 250
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  container:{
    padding: 1,
  },
  button:{
    marginTop: 5,
    padding: 1,
    height: 52,
    width: 52,
  },
})