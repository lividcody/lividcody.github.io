import React, {useState} from 'react';
import {StyleSheet, TextInput, Button, View} from 'react-native';

export default function AddToDo({submitHandler}){
  
  const [text, setText] = useState('')

  const changeHandler = (val) => {
    setText(val)
  }
  
  return(
    <View>
      <View style={styles.inputContainer}>
        <TextInput 
          style={styles.input}
          placeholder='Task TO-DO.......'
          onChangeText={changeHandler}
        />
      </View>
      <Button 
        style={styles.button}
        title='ADD TASK'
        onPress={() => submitHandler(text)}
      />      
    </View>
  )
}

const styles = StyleSheet.create({
  inputContainer:{
   padding: 1,
  },
  input:{
    backgroundColor: "white",
    height: 40,
    width: 294,
    fontSize: 20,
    borderWidth: 1,
    borderColor: "black",
  },
  button:{
    textAlign: "center",
    fontSize: 20,
    paddingLeft: 20,
    color: "blue",
  },
});