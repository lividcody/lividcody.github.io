import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default function Footer(){
  return(
    <View><Text style={styles.footer}>DONE-YET?</Text>
    </View>
  )
}

const styles= StyleSheet.create({
  footer:{
    textAlign: 'center', 
    fontWeight: 'bold',
    fontSize: 20, 
    padding: 10, 
    textDecorationLine: "underline"
  },
})