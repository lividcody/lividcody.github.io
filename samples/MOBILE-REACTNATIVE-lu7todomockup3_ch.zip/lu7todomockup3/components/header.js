import React from 'react';
import { Text, View, StyleSheet, } from 'react-native';

export default function Header(){
  return(
    <View><Text style={styles.header}>TO-DO</Text>
    </View>
  )
}

const styles= StyleSheet.create({
  header:{
    textAlign: 'center', 
    fontWeight: 'bold',
    fontSize: 40, 
    padding: 20, 
    textDecorationLine: "underline"
  },
})